package intro;

public interface Pet {

}
