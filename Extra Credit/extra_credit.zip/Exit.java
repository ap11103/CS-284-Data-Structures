package runtime;

public class Exit extends Instruction {

	Exit(int code, String mnemonic) {
		super(code,mnemonic);
	}
}

