package runtime;

public class Add extends Instruction {
  
	
	Add(int code, String mnemonic) {
		super(code,mnemonic);
	}
	
	
}